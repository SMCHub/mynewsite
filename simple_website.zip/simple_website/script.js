document.getElementById('clickMe').addEventListener('click', function() {
    alert('Button clicked!');
});